

package org.myproject.ms.monitoring;


public interface ItemAdjuster {
	
	Item adjust(Item span);
}
