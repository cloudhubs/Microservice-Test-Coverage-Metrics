

package org.myproject.ms.monitoring;


public interface ItemNamer {

	
	String name(Object object, String defaultValue);
}
