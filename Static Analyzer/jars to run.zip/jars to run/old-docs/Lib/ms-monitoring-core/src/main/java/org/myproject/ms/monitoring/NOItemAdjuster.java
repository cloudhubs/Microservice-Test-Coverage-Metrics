

package org.myproject.ms.monitoring;


public class NOItemAdjuster implements ItemAdjuster {
	@Override public Item adjust(Item span) {
		return span;
	}
}
