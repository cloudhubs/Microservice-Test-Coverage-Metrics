

package org.myproject.ms.monitoring.antn;


public interface TagValueExpressionResolver {

	
	String resolve(String expression, Object parameter);
	
}
