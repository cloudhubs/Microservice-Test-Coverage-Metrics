package org.myproject.ms.monitoring.instrument.web;

import org.myproject.ms.monitoring.ItemExtractor;
import org.myproject.ms.monitoring.ItemTextMap;


public interface HSExtra extends ItemExtractor<ItemTextMap> {
}
