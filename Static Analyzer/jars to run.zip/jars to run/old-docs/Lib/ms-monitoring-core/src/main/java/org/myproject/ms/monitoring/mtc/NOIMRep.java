package org.myproject.ms.monitoring.mtc;


public class NOIMRep implements ItemMetricReporter {

	public void incrementAcceptedSpans(long quantity) {

	}

	public void incrementDroppedSpans(long quantity) {

	}
}