Ypackage auth.init;

import auth.entity.AuthUser;
import auth.repository.AuthUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.UUID;

/**
 * @author fdse
 */
@Component
public class InitUser implements CommandLineRunner {

    @Autowired
    private AuthUserRepository authUserRepository;

    @Autowired
    protected PasswordEncoder passwordEncoder;


    @Override
    public void run(String... strings) throws Exception {
        AuthUser whetherExistAuthUser = authUserRepository.findByUsername("fdse_microservice").orElse(new AuthUser());
        if (whetherExistAuthUser.getUsername() == null) {
            AuthUser authUser = AuthUser.builder()
                    .userId("4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f")
                    .username("fdse_microservice")
                    .password(passwordEncoder.encode("111111"))
                    .roles(new HashSet<>(Arrays.asList("ROLE_USER")))
                    .build();
            authUserRepository.save(authUser);
        }

        AuthUser whetherExistAdmin = authUserRepository.findByUsername("admin").orElse(new AuthUser());
        if (whetherExistAdmin.getUsername() == null) {
            AuthUser admin = AuthUser.builder()
                    .userId(UUID.randomUUID().toString())
                    .username("admin")
                    .password(passwordEncoder.encode("222222"))
                    .roles(new HashSet<>(Arrays.asList("ROLE_ADMIN")))
                    .build();
            authUserRepository.save(admin);
        }
    }
}
