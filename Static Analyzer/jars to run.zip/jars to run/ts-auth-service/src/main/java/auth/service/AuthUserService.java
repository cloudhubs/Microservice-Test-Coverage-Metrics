package auth.service;

import auth.dto.AuthDto;
import auth.entity.AuthUser;
import edu.fudan.common.util.Response;
import org.springframework.http.HttpHeaders;

import java.util.List;

/**
 * @author fdse
 */
public interface AuthUserService {

    /**
     * save user
     *
     * @param authUser user
     * @return user
     */
    AuthUser saveUser(AuthUser authUser);

    /**
     * get all users
     *
     * @param headers headers
     * @return List<User>
     */
    List<AuthUser> getAllUser(HttpHeaders headers);

    /**
     * create default auth user
     *
     * @param dto dto
     * @return user
     */
    AuthUser createDefaultAuthUser(AuthDto dto);

    /**
     * delete by user id
     *
     * @param userId user id
     * @param headers headers
     * @return Response
     */
    Response deleteByUserId(String userId, HttpHeaders headers);

}
