package auth.service;

import auth.dto.AuthDto;
import auth.entity.AuthUser;
import auth.repository.AuthUserRepository;
import auth.service.impl.AuthUserServiceImpl;
import edu.fudan.common.util.Response;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

@RunWith(JUnit4.class)
public class AuthAuthUserServiceImplTest {

    @InjectMocks
    private AuthUserServiceImpl userServiceImpl;

    @Mock
    private AuthUserRepository authUserRepository;
    @Mock
    protected PasswordEncoder passwordEncoder;

    private HttpHeaders headers = new HttpHeaders();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveUser() {
        AuthUser authUser = new AuthUser();
        Assert.assertEquals(null, userServiceImpl.saveUser(authUser));
    }

    @Test
    public void testGetAllUser() {
        List<AuthUser> authUserList = new ArrayList<>();
        authUserList.add(new AuthUser());
        Mockito.when(authUserRepository.findAll()).thenReturn(authUserList);
        Assert.assertEquals(authUserList, userServiceImpl.getAllUser(headers));
    }

    @Test
    public void testCreateDefaultAuthUser() {
        AuthDto dto = new AuthDto(UUID.randomUUID().toString(), "username", "password");
        AuthUser authUser = new AuthUser();
        Mockito.when(authUserRepository.save(authUser)).thenReturn(authUser);
        Mockito.when(passwordEncoder.encode(dto.getPassword())).thenReturn("password");
        Assert.assertEquals(null, userServiceImpl.createDefaultAuthUser(dto));
    }

    @Test
    public void testDeleteByUserId() {
        UUID userId = UUID.randomUUID();
        Mockito.doNothing().doThrow(new RuntimeException()).when(authUserRepository).deleteByUserId(userId.toString());
        Assert.assertEquals(new Response(1, "DELETE USER SUCCESS", null), userServiceImpl.deleteByUserId(userId.toString(), headers));
    }

}
